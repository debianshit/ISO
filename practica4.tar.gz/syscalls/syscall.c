#include <linux/unistd.h>
#include <sys/syscall.h>

int main(int argc, char** argv){
	int ctr = syscall(312);
	printf("Num. Generaciones: %i\n", ctr);
	return 0;
}
